import React, { Component } from 'react'
class UserGreeting extends Component {
    constructor(props){
        super(props)
        this.state = {
            isLoggedIn: true
        }
    }
    render() {
        //this.state.isLoggedIn ?(
        //<div>Welcome Lavanya</div>
         //) :(
        //<div>Welcome Guest</div>
         //)

        let message
        if(this.state.isLoggedIn) {
            message = <div>Welcome Lavanya</div>
        }else {
            message = <div>Welcome Guest</div>
        }
        return <div>{message}</div>
       //if(this.state.isLoggedIn) {
         //   return (
           //     <div>
             //       Welcome Lavanya
               // </div>
            //)
            //}else {
            //    return (
              //      <div>
                //        Welcome Guest
                  //  </div>
                //)
            //}
       // return(
         //   <div>
           //     <div>Welcome Suma</div>
             //   <div>Welcome Guest</div>

            //</div>
        //)
    }
}
export default UserGreeting